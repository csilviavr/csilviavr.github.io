function [lndetSigma]=lndet(Sigma);

lndetSigma=2*sum(log(diag(chol(Sigma))),1);