function [KL]=KL_gamma(q1,q2,p1,p2)

% Calculates KL(q||p)=<ln q(x)/p(x)>_q(x) 
% where q and p are Gamma distributions with parameters q1,q2 and p1,p2.

digamma=psi(q1); % digamma=mfun('Psi',q1);
KL=sum(q1.*log(q2)-p1.*log(p2)-gammaln(q1)+gammaln(p1)+(q1-p1).*(digamma-log(q2))-(q2-p2).*q1./q2 ,1);





