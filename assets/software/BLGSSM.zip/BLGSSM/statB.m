function [mB,SB,NB,IHB]=statB(avHtVt,avHtHt,beta,hatB)

% Compute the mean of q(B|SigmaV) and SB=<B'SigmaV^{-1}B>-<B'><SigmaV^{-1}><B>

[H,V]=size(avHtVt);
HB=zeros(H);
NB=zeros(V,H);

for i=1:H
    HB(i,:)=avHtHt(:,i)';
end
HB=HB+diag(beta);
IHB=inv(HB);
for i=1:V
    NB(i,:)=avHtVt(:,i)'+beta'.*hatB(i,:);
end
mB=NB*IHB;
SB=V*IHB;
SB=0.5*(SB+SB');

    
    
    
	   
    
    