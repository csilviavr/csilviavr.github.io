%--------------------------------------------------------------------------------------------------------
% Variational Bayesian Linear Gaussian State-Space Models (aka Linear Dynamical Systems, Kalman Filters)
%
% h(t) = Ah(t-1) + etah(t), etah(t)~N(0,SigmaH), etah(1)~N(mu,Sigma)
% v(t) = Bh(t) + etav(t), etav(t)~N(0,SigmaV)

% Assume a Gaussian prior on the elements of A and on the columns of B 
% p(A|alpha) propto prod exp[-0.5 alpha(i,j)ISigmaH(i,i)(A(i,j)-hatA(i,j))^2]
% p(B|beta) propto prod exp[-0.5 beta(j)(B(:,j)-hatB(:,j))'ISigmaV(B(:,j)-hatB(:,j))]

% Assume a Gamma prior on the inverse of diagonal covariances SigmaH and SigmaV

% No prior on mu and Sigma, wich are considered as hyperparameters

% Reference:
% David Barber & Silvia Chiappa,
% Unified Inference for Variational Bayesian Linear Gaussian State-Space Models, NIPS 20
%
% Created in January 2007 by Silvia Chiappa, email:silvia.chiappa@tuebingen.mpg.de
% Last Modification: 30/07/2007

%--------------------------------------------------------------------------------------------------------

function BLGSSM=VBLGSSM(maxiter,BLGSSM)

[V,T]=size(BLGSSM.v);
H=size(BLGSSM.mA,1);

% Run the standard KF
[mean_post,cov_post,pair_cov_post]=forward_pc_backward_rts(BLGSSM.v,BLGSSM.mA,BLGSSM.mB,BLGSSM.mSigmaH,...
                                                           BLGSSM.mSigmaV,BLGSSM.mu,BLGSSM.Sigma);

%--------------------------------------------------------------------------------------------------------------
% COMPUTE sum <h(t)h(t)'>_q(h(t)) sum <h(t-1)h(t)'>_q(h(t-1:t))
%         sum <h(t)>_q(h(t))v(t)' sum v(t)v(t)'
%--------------------------------------------------------------------------------------------------------------

avHtmHtm=zeros(H);avHtHt=zeros(H);avHtmHt=zeros(H);avH1HtH1Ht=zeros(H);avHtVt=zeros(H,V);avVtVt=zeros(V);
avHtmHtm=sum(cov_post(:,:,1:T-1),3)+mean_post(:,1:T-1)*mean_post(:,1:T-1)';
avHtHt=sum(cov_post(:,:,2:T),3)+mean_post(:,2:T)*mean_post(:,2:T)';
avHtmHt=sum(pair_cov_post(:,:,2:T),3)+mean_post(:,1:T-1)*mean_post(:,2:T)';
avH1HtH1Ht=avHtmHtm+cov_post(:,:,T)+mean_post(:,T)*mean_post(:,T)';
avHtVt=mean_post(:,1:T)*BLGSSM.v(:,1:T)';
avVtVt=BLGSSM.v(:,1:T)*BLGSSM.v(:,1:T)';

figure(3)
scrsz=get(0,'ScreenSize');
set(gcf,'Position',[1 scrsz(4) scrsz(3) scrsz(4)])

for emloop=1:maxiter 
    
    if (~mod(emloop,10))
        emloop
    end
    
    %----------------------------------------------------------------------------
    % COMPUTE THE REQUIRED STATISTICS OF THE PARAMETERS Theta={A,B,SigmaH,SigmaV}
    %----------------------------------------------------------------------------
    
    [BLGSSM.mA,SA,NA,IHA,MA]=statA(avHtmHtm,avHtmHt,BLGSSM.alpha,BLGSSM.hatA);
    [BLGSSM.mB,SB,NB,IHB]=statB(avHtVt,avH1HtH1Ht,BLGSSM.beta,BLGSSM.hatB);
    [BLGSSM.mSigmaH,BLGSSM.qa1,BLGSSM.qa2]=statSigmaH(avHtHt,BLGSSM.pa1,BLGSSM.pa2,...
                                                      BLGSSM.alpha,BLGSSM.hatA,NA,IHA,T);   
    [BLGSSM.mSigmaV,BLGSSM.qb1,BLGSSM.qb2]=statSigmaV(avVtVt,BLGSSM.pb1,BLGSSM.pb2,...
                                                      BLGSSM.beta,BLGSSM.hatB,NB,IHB,BLGSSM.v);
    
    %---------------------------------------------------------------------------------------------------
    % COMPUTE MEAN AND COVARIANCE OF q(h(t)) AND THE ENTROPY -<log q(h(t))>_q(h(t))
    %---------------------------------------------------------------------------------------------------

    % Run forward and backward algorithms 
    UAB=chol(SA+SB);
    UABT=chol(SB);
    [mean_post,cov_post,pair_cov_post,q_entropy]=forward_mf_backward_rts(BLGSSM.v,BLGSSM.mA,BLGSSM.mB,BLGSSM.mSigmaH,...
                                                                         BLGSSM.mSigmaV,BLGSSM.mu,BLGSSM.Sigma,UAB,UABT); 

    %----------------------------------------------------------------------------
    % COMPUTE sum <h(t)h(t)'>_q(h(t)) sum <h(t-1)h(t)'>_q(h(t-1:t)) 
    %         sum <h(t)>_q(h(t))v(t)' 
    %----------------------------------------------------------------------------  
    
    avHtmHtm=sum(cov_post(:,:,1:T-1),3)+mean_post(:,1:T-1)*mean_post(:,1:T-1)';
    avHtHt=sum(cov_post(:,:,2:T),3)+mean_post(:,2:T)*mean_post(:,2:T)';
    avHtmHt=sum(pair_cov_post(:,:,2:T),3)+mean_post(:,1:T-1)*mean_post(:,2:T)';
    avH1HtH1Ht=avHtmHtm+cov_post(:,:,T)+mean_post(:,T)*mean_post(:,T)';
    avHtVt=mean_post(:,1:T)*BLGSSM.v(:,1:T)';
    
    %----------------------------------------------------------------
    % CALCULATE LOG-LIKELIHOOD LOWER BOUND F
    %----------------------------------------------------------------
    
    ImSigmaH=inv(BLGSSM.mSigmaH);
    mAISigmaHA=SA+BLGSSM.mA'*ImSigmaH*BLGSSM.mA;
    ImSigmaV=inv(BLGSSM.mSigmaV);
    mBISigmaVB=SB+BLGSSM.mB'*ImSigmaV*BLGSSM.mB;
     
    BLGSSM.F(emloop)=loglik_bound(T,BLGSSM.qa1,BLGSSM.qa2,BLGSSM.pa1,BLGSSM.pa2,BLGSSM.qb1,BLGSSM.qb2,...
                                  BLGSSM.pb1,BLGSSM.pb2,BLGSSM.alpha,BLGSSM.beta,ImSigmaH,mAISigmaHA,ImSigmaV,...
                                  mBISigmaVB,avHtmHtm,avHtmHt,avHtHt,avH1HtH1Ht,avHtVt,avVtVt,IHA,IHB,BLGSSM.mA,...
                                  BLGSSM.mB,BLGSSM.hatA,BLGSSM.hatB,BLGSSM.mu,BLGSSM.Sigma,mean_post,cov_post,q_entropy);

    %----------------------------------------------------------------
    % UPDATE HYPERPARAMETERS HATTHETA={alpha,beta,mu,Sigma}
    %----------------------------------------------------------------
    
    % Update alpha parameters
    D=repmat(diag(ImSigmaH),1,H);
    mAISigmaHA=MA+D.*(BLGSSM.mA.^2);
    mhatAISigmaHhatA=D.*(BLGSSM.hatA.^2);
    mAISigmaHhatA=D.*(BLGSSM.hatA.*BLGSSM.mA);        
    for j=1:H
        BLGSSM.alpha(:,j)=1./(mAISigmaHA(:,j)-2*mAISigmaHhatA(:,j)+mhatAISigmaHhatA(:,j));
    end

    % Update beta parameters
    mhatBISigmaVhatB=BLGSSM.hatB'*ImSigmaV*BLGSSM.hatB;
    mBISigmaVhatB=BLGSSM.mB'*ImSigmaV*BLGSSM.hatB;
    for j=1:H
        BLGSSM.beta(j)=V/(mBISigmaVB(j,j)-2*mBISigmaVhatB(j,j)+mhatBISigmaVhatB(j,j));
    end
    
    % Update mean and covariance of h(1)
    % mu=mean_post(:,1); 
    % Sigma=cov_post(:,:,1);
    CT=-mean_post(:,1)*BLGSSM.mu'; 
    BLGSSM.Sigma=cov_post(:,:,1)+mean_post(:,1)*mean_post(:,1)'+CT+CT'+BLGSSM.mu*BLGSSM.mu';
    BLGSSM.mu=mean_post(:,1);
    
    if (~mod(emloop,10))
        mAn=BLGSSM.mA./max(max(abs(BLGSSM.mA)));
        act=0;
        for i=1:H
            for j=1:H
                if(abs(mAn(i,j))>10e-5)
                    act=act+1;
                end
            end
        end
        subplot(1,3,1);imagesc(BLGSSM.mA),colormap(gray)
        title('Mean of q(A)')
        set(gca,'XTick',[1:H])
        set(get(gca,'XLabel'),'String','H')
        set(gca,'YTick',[1:H])
        set(get(gca,'YLabel'),'String','H')
        colorbar

        mBn=BLGSSM.mB./max(max(abs(BLGSSM.mB)));
        act=0;
        for j=1:H
            if(max(abs(mBn(:,j)))>10e-5)
                act=act+1;
            end
        end
        subplot(1,3,2);imagesc(BLGSSM.mB),colormap(gray)
        title('Mean of q(B)')
        set(gca,'XTick',[1:H])
        set(get(gca,'XLabel'),'String','H')
        set(gca,'YTick',[1:V])
        set(get(gca,'YLabel'),'String','V')
        colorbar
        
        subplot(1,3,3);plot(BLGSSM.F)
        title('Log-likelihood Bound')
        axis tight
        drawnow
    end
        
end
