function [mSigmaH,qa1,qa2]=statSigmaH(avHtHt,pa1,pa2,alpha,hatA,NA,IHA,T)

% Compute mean and parameters qa1 and qa2 of q(SigmaH)

H=size(IHA{1},1);
mSigmaH=zeros(H);
qa2=zeros(H,1);

qa1=pa1+0.5*(T-1);
for i=1:H
    G=NA(i,:)*IHA{i}*NA(i,:)';
    C=sum(alpha(i,:).*hatA(i,:).^2);
    qa2(i)=pa2(i)+0.5*(avHtHt(i,i)-G+C);
    mSigmaH(i,i)=qa2(i)/qa1;
end


    