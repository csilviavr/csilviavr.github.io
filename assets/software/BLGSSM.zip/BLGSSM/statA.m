function [mA,SA,NA,IHA,MA]=statA(avHtmHtm,avHtmHt,alpha,hatA)

% Compute the mean of q(A|SigmaH) and SA=<A'SigmaH^{-1}A>-<A'><SigmaH^{-1}><A>

H=size(alpha,1);
HA=cell(H,1);
IHA=cell(H,1);
MA=zeros(H);
NA=zeros(H);
mA=zeros(H);
SA=zeros(H);

for i=1:H
    HA{i}=zeros(H);
    for j=1:H
        HA{i}(j,:)=avHtmHtm(j,:);
    end
    HA{i}=HA{i}+diag(alpha(i,:));
    IHA{i}=inv(HA{i});
    for j=1:H
        MA(i,j)=IHA{i}(j,j);     
    end
    NA(i,:)=avHtmHt(:,i)'+alpha(i,:).*hatA(i,:);
    mA(i,:)=NA(i,:)*IHA{i};
    SA=SA+IHA{i}';
end
SA=0.5*(SA+SA');
    


  
    
    
    
    
	   
    
    