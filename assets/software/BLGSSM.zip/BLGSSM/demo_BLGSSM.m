% Demo for the Variational Bayesian Linear Gaussian State-Space Model (BLGSSM)

% We generate some data from a LGSSM with a given hidden dimension.
% We then try to infer the most parsimonious parameterization consistent with the data 
% using a variational BLGSSM. Notice that, for this general model, the most parsimonious 
% parameterization is not always in agreement with the number of parameters the data has been 
% generated with. Indeed there may be cases in which the original parameter number can be 
% reduced without affecting the goodness of the model in explaining the data. Therefore, 
% we can easily see if the variational BLGSSM does not remove enough parameters,
% but it is more difficult to see whether the model has pruned too many parameters.

% We generate some data from a LGSSM with hidden dimension H=2.
% The Variation BLGSSM finds that 2 hidden variables (starting from 10) contribute to the observations.
% Unlike the original A matrix, the mean of q(A) has only two elements which are different from zero.

maxiter=500; % Number of iterations for variational EM 
T=100; % Time-series length

% Generate some data
randn('state',100)
V=2;oH=2; % Visible dimension and original hidden dimension
A=0.9999*orth(randn(oH));
randn('state',500)
B=randn(V,oH);
r=randn(oH);
SigmaH=0.01*eye(oH);
SigmaV=0.01*eye(V);
mu=zeros(oH,1);
Sigma=0.1*eye(oH);

h(:,1)=mvnrnd(mu',Sigma,1)';
v(:,1)=B*h(:,1)+mvnrnd(zeros(V,1),SigmaV,1)';
for t=2:T
    h(:,t)=A*h(:,t-1)+mvnrnd(zeros(oH,1),SigmaH,1)';
    v(:,t)=B*h(:,t)+mvnrnd(zeros(V,1),SigmaV,1)';
end

figure(1),subplot(V,1,1);title('Observations') 
for i=1:V
    subplot(V,1,i)
    hold on
    plot(v(i,:))
end
figure(2),subplot(oH,1,1);title('Hidden Variables') 
for i=1:oH
    subplot(oH,1,i)
    hold on
    plot(h(i,:))
end

% Initialization and setting of hatA and hatB
BLGSSM.v=v;
H=10; % Start from higher hidden dimension that the original one
BLGSSM.hatA=zeros(H); % Set hatA to zero to eliminate unecessary parameters
BLGSSM.hatB=zeros(V,H); % Set hatB to zero to eliminate unecessary parameters
BLGSSM.mA=0.9999*orth(randn(H));
BLGSSM.mB=randn(V,H);
BLGSSM.mSigmaH=1*eye(H);
BLGSSM.mSigmaV=1*eye(V);
BLGSSM.mu=randn(H,1);
BLGSSM.Sigma=1*eye(H);
BLGSSM.alpha=0.0001*abs(rand(H));
BLGSSM.beta=0.0001*ones(H,1);
BLGSSM.pa1=2;
BLGSSM.pa2=0.5*ones(H,1);
BLGSSM.pb1=2;
BLGSSM.pb2=0.5*ones(V,1);

BLGSSM=VBLGSSM(maxiter,BLGSSM);

figure(3)
scrsz=get(0,'ScreenSize');
set(gcf,'Position',[1 scrsz(4) scrsz(3) scrsz(4)])
mAn=BLGSSM.mA./max(max(abs(BLGSSM.mA)));
act=0;
for i=1:H
    for j=1:H
        if(abs(mAn(i,j))>10e-5)
            act=act+1;
        end
    end
end
subplot(1,3,1);imagesc(BLGSSM.mA),colormap(gray)
title({'Mean of q(A): number of elements reduced', ['from ' num2str(H^2) ' to '  num2str(act) ' (data generated with H^2=' num2str(oH^2) ')']})
set(gca,'XTick',[1:H])
set(get(gca,'XLabel'),'String','H')
set(gca,'YTick',[1:H])
set(get(gca,'YLabel'),'String','H')
colorbar

mBn=BLGSSM.mB./max(max(abs(BLGSSM.mB)));
act=0;
for j=1:H
    if(max(abs(mBn(:,j)))>10e-5)
        act=act+1;
    end
end
subplot(1,3,2);imagesc(BLGSSM.mB),colormap(gray)
title({'Mean of q(B): number of columns reduced',['from ' num2str(H) ' to '  num2str(act) ' (data generated with H=' num2str(oH) ')']})
set(gca,'XTick',[1:H])
set(get(gca,'XLabel'),'String','H')
set(gca,'YTick',[1:V])
set(get(gca,'YLabel'),'String','V')
colorbar

subplot(1,3,3);plot(BLGSSM.F)
title('Log-likelihood Bound')
axis tight


  
  






