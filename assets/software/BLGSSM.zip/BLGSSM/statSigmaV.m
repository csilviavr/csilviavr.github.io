function [mSigmaV,qb1,qb2]=statSigmaV(avVtVt,pb1,pb2,beta,hatB,NB,IHB,v)

% Compute mean and parameters qb1 and qb2 of q(SigmaV)

[V,T]=size(v); H=size(IHB,1);
mSigmaV=zeros(V);
qb2=zeros(V,1);

G=NB*IHB*NB';
qb1=pb1+0.5*T;
for i=1:V
    C=sum(beta'.*hatB(i,:).^2);
    qb2(i)=pb2(i)+0.5*(sum(v(i,:).^2)-G(i,i)+C);
    mSigmaV(i,i)=qb2(i)/qb1;
end

