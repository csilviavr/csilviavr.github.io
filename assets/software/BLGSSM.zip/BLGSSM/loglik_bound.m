function [bound]=loglik_bound(T,qa1,qa2,pa1,pa2,qb1,qb2,pb1,pb2,alpha,beta,ImSigmaH,mAISigmaHA,ImSigmaV,mBISigmaVB,avHtmHtm,avHtmHt,avHtHt,avH1HtH1Ht,avHtVt,avVtVt,IHA,IHB,mA,mB,hatA,hatB,mu,Sigma,mean_post,cov_post,q_entropy)

% Calculate the lower bound of the log-likelihood

H=size(ImSigmaH,1);
V=size(ImSigmaV,1);

tmp1=ImSigmaH*avHtHt; 
% tmp2=mA'*ImSigmaH*avHtmHt'; 
tmp3=ImSigmaH*mA*avHtmHt; 
tmp4=mAISigmaHA*avHtmHtm; 

tmp5=ImSigmaV*avVtVt; 
% tmp6=mB'*ImSigmaV*avHtVt'; 
tmp7=ImSigmaV*mB*avHtVt; 
tmp8=mBISigmaVB*avH1HtH1Ht; 

digammah=psi(qa1); % digammah=mfun('Psi',qa1);
digammav=psi(qb1); % digammav=mfun('Psi',qb1);

bound=-0.5*(trace(tmp1)-2*trace(tmp3)+trace(tmp4)...
    -(T-1)*(sum(digammah-log(qa2))-H*log(2*pi))); % <log p(h(2:T)|h(1)))>_q(h(1:T))q(A,SigmaH)

CT=-mean_post(:,1)*mu';
bound=bound-0.5*trace(inv(Sigma)*(cov_post(:,:,1)+mean_post(:,1)*mean_post(:,1)'...
    +CT+CT'+mu*mu'))-0.5*lndet(Sigma)-0.5*H*log(2*pi); % <log p(h(1)|v(1:T))>_q(h(1))

bound=bound-0.5*((trace(tmp5)-2*trace(tmp7)+trace(tmp8))...
    -T*(sum(digammav-log(qb2))-V*log(2*pi))); % <log p(v(1:T)|h(1:T))>_q(h(1:T))q(B,SigmaV)

bound=bound-KL_gamma(qa1,qa2,pa1,pa2); % <log q(ISigmaH)/p(ISigmaH)>_q(ISigmaH)
bound=bound-KL_gamma(qb1,qb2,pb1,pb2); % <log q(ISigmaV)/p(ISigmaV)>_q(ISigmaV)

bound=bound+q_entropy;

% pcovSigmaV=[];
% for i=1:H
%     pcovSigmaV=blkdiag(pcovSigmaV,beta(i)*eye(V));
% end
% 
% covSigmaV=kron(IHB,eye(V));
% 
% [vmB]=mat2vec_c(mB);
% [vhatB]=mat2vec_c(hatB);
% 
% % <log q(B|ISigmaV)/p(B|ISigmaV)>_q(B,ISigmaV)
% bound=bound-(-1/2*(log(det(pcovSigmaV*covSigmaV)))...
%     +1/2*trace(pcovSigmaV*covSigmaV-eye(V*H))...
%     +1/2*trace(kron(diag(beta),ImSigmaV)*(vmB-vhatB)*(vmB-vhatB)')...
%     );

% <log q(B|ISigmaV)/p(B|ISigmaV)>_q(B,ISigmaV)
bound=bound-(-V/2*(log(prod(beta))+lndet(IHB))...
    +V/2*trace(diag(beta)*IHB-eye(H))...
    +1/2*trace(diag(beta)*(mB-hatB)'*ImSigmaV*(mB-hatB))...
    );
   
% pcovSigmaH=[];
% pcovSigmaHH=[];
% for i=1:H
%     pcovSigmaHH=blkdiag(pcovSigmaHH,diag(ImSigmaH(i,i)*alpha(i,:)));
%     pcovSigmaH=blkdiag(pcovSigmaH,diag(alpha(i,:)));
% end
% 
% covSigmaH=[];
% for i=1:H
%     covSigmaH=blkdiag(covSigmaH,IHA{i});
% end
% 
% [vmA]=mat2vec_r(mA);
% [vhatA]=mat2vec_r(hatA);
% 
% % <log q(A|ISigmaH)/p(A|ISigmaH)>_q(A,ISigmaH)
% bound=bound-(-1/2*log(det(pcovSigmaH*covSigmaH))...
%     +1/2*trace(pcovSigmaH*covSigmaH-eye(H^2))...
%     +1/2*trace(pcovSigmaHH*(vmA-vhatA)*(vmA-vhatA)')...
%     );

% <log q(A|ISigmaH)/p(A|ISigmaH)>_q(A,ISigmaH)
for i=1:H
     bound=bound-(-1/2*(log(prod(alpha(i,:)))+lndet(IHA{i}))...
     +1/2*(trace(diag(alpha(i,:))*IHA{i}-eye(H)))...
     +1/2*trace(diag(ImSigmaH(i,i)*alpha(i,:))*(mA(i,:)-hatA(i,:))'*(mA(i,:)-hatA(i,:))));
end


    
