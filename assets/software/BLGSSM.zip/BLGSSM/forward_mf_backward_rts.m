function [mean_post,cov_post,pair_cov_post,entropy]=forward_mf_backward_rts(v,A,B,SigmaH,SigmaV,mu,Sigma,UAB,UABT)

H=size(A,1); [V,T]=size(v);

PredP=zeros(H,H,T);FiltP=zeros(H,H,T);
hpred=zeros(H,T);hfilt=zeros(H,T);
mean_post=zeros(H,T);cov_post=zeros(H,H,T);pair_cov_post=zeros(H,H,T);
    
% Forward pass: perform filtering using the modified predictor-corrector algorithm (Joseph's form)
D=eye(H)-Sigma*UAB'*inv(eye(H)+UAB*Sigma*UAB')*UAB; 
PredP(:,:,1)=Sigma;
P=D*Sigma;
Pzz=B*P*B'+SigmaV;
K=P*B'*inv(Pzz);
hpred(:,1)=mu;
% FiltP(:,:,1)=PredP(:,:,1)-K*B*PredP(:,:,1);
IKB=eye(H)-K*B;
FiltP(:,:,1)=IKB*P*IKB'+K*SigmaV*K';
if (~isequal(FiltP(:,:,1),FiltP(:,:,1)'))
    FiltP(:,:,1)=(FiltP(:,:,1)+FiltP(:,:,1)')/2;
end
hfilt(:,1)=D*hpred(:,1)+K*(v(:,1)-B*D*hpred(:,1)); 

for t=2:T
    if (t==T)
        UAB=UABT;
    end
    PredP(:,:,t)=A*FiltP(:,:,t-1)*A'+SigmaH; 
    D=eye(H)-PredP(:,:,t)*UAB'*inv(eye(H)+UAB*PredP(:,:,t)*UAB')*UAB;
    P=D*PredP(:,:,t);
    Pzz=B*P*B'+SigmaV;
    K=P*B'*inv(Pzz);
    % FiltP(:,:,t)=PredP(:,:,t)-K*B*PredP(:,:,t);
    IKB=eye(H)-K*B;
    FiltP(:,:,t)=IKB*P*IKB'+K*SigmaV*K';
    if (~isequal(FiltP(:,:,t),FiltP(:,:,t)'))
        FiltP(:,:,t)=(FiltP(:,:,t)+FiltP(:,:,t)')/2;
    end
    hpred(:,t)=A*hfilt(:,t-1);
    hfilt(:,t)=D*hpred(:,t)+K*(v(:,t)-B*D*hpred(:,t));  
end

% Backward pass: perform smoothing using the Raugh-Stung-Striebel algorithm
mean_post(:,T)=hfilt(:,T);
cov_post(:,:,T)=FiltP(:,:,T); 
entropy=0;
for t=T-1:-1:1
    leftA=FiltP(:,:,t)*A'*inv(PredP(:,:,t+1)); 
    mean_post(:,t)=hfilt(:,t)+leftA*(mean_post(:,t+1)-A*hfilt(:,t));
    tmp=eye(H)-leftA*A;
    cov_post(:,:,t)=tmp*FiltP(:,:,t)*tmp'+leftA*SigmaH*leftA'+leftA*cov_post(:,:,t+1)*leftA';
    if (~isequal(cov_post(:,:,t),cov_post(:,:,t)'))
        cov_post(:,:,t)=(cov_post(:,:,t)+cov_post(:,:,t)')/2;
    end
    % Compute <(h(t)-mean_post(t,:))(h(t+1)-mean_post(t+1,:))'>
    pair_cov_post(:,:,t+1)=leftA*cov_post(:,:,t+1);
    entropy=entropy+0.5*lndet(cov_post(:,:,t)-pair_cov_post(:,:,t+1)*leftA');
end
entropy=entropy+0.5*lndet(cov_post(:,:,T))+T*0.5*H*(1+log(2*pi));



    