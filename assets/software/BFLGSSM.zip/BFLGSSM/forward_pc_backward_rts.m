function [mean_post,cov_post,pair_cov_post,entropy]=forward_pc_backward_rts(v,A,B,BT,SigmaH,SigmaV,mu,Sigma)

H=size(A,1); [V,T]=size(v);

PredP=zeros(H,H,T);FiltP=zeros(H,H,T);
hpred=zeros(H,T);hfilt=zeros(H,T);
mean_post=zeros(H,T);cov_post=zeros(H,H,T);pair_cov_post=zeros(H,H,T);

% Forward pass: perform filtering using the predictor-corrector algorithm (Joseph's form)
PredP(:,:,1)=Sigma;
Pzz=B*PredP(:,:,1)*B'+SigmaV;
K=PredP(:,:,1)*B'*inv(Pzz);
hpred(:,1)=mu;
% FiltP(:,:,1)=PredP(:,:,1)-K*B*PredP(:,:,1);
IKB=eye(H)-K*B;
FiltP(:,:,1)=IKB*PredP(:,:,1)*IKB'+K*SigmaV*K';
if (~isequal(FiltP(:,:,1),FiltP(:,:,1)'))
    FiltP(:,:,1)=(FiltP(:,:,1)+FiltP(:,:,1)')/2;
end
hfilt(:,1)=hpred(:,1)+K*(v(:,1)-B*hpred(:,1));

for t=2:T
    if (t==T)
        B=BT;
    end
    PredP(:,:,t)=A*FiltP(:,:,t-1)*A'+SigmaH;
    Pzz=B*PredP(:,:,t)*B'+SigmaV;
    K=PredP(:,:,t)*B'*inv(Pzz);
    % FiltP(:,:,t)=PredP(:,:,t)-K*B*PredP(:,:,t);
    IKB=eye(H)-K*B;
    FiltP(:,:,t)=IKB*PredP(:,:,t)*IKB'+K*SigmaV*K';
    if (~isequal(FiltP(:,:,t),FiltP(:,:,t)'))
        FiltP(:,:,t)=(FiltP(:,:,t)+FiltP(:,:,t)')/2;
    end
    hpred(:,t)=A*hfilt(:,t-1);
    hfilt(:,t)=hpred(:,t)+K*(v(:,t)-B*hpred(:,t));
end

% Backward pass: perform smoothing using the Raugh-Stung-Striebel algorithm
mean_post(:,T)=hfilt(:,T);
cov_post(:,:,T)=FiltP(:,:,T);
entropy=0;
for t=T-1:-1:1
    leftA=FiltP(:,:,t)*A'*inv(PredP(:,:,t+1)); 
    mean_post(:,t)=hfilt(:,t)+leftA*(mean_post(:,t+1)-A*hfilt(:,t));
    tmp=eye(H)-leftA*A;
    cov_post(:,:,t)=tmp*FiltP(:,:,t)*tmp'+leftA*SigmaH*leftA'+leftA*cov_post(:,:,t+1)*leftA';
    if (~isequal(cov_post(:,:,t),cov_post(:,:,t)'))
        cov_post(:,:,t)=(cov_post(:,:,t)+cov_post(:,:,t)')/2;
    end
    % Compute <(h(t)-mean_post(t,:))(h(t+1)-mean_post(t+1,:))'>
    pair_cov_post(:,:,t+1)=leftA*cov_post(:,:,t+1);
    entropy=entropy+0.5*lndet(cov_post(:,:,t)-pair_cov_post(:,:,t+1)*leftA');
end
entropy=entropy+0.5*lndet(cov_post(:,:,T))+T*0.5*H*(1+log(2*pi));

    