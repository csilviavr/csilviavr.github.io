function [mSigmaH,qa1,qa2]=statSigmaH(avHtHt,pa1,pa2,alpha,hatA,NA,IHA,T,indx)

% Compute mean and parameters qa1 and qa2 of q(SigmaH)

C=length(indx);

mSigmaH=[];qa2=[];

for c=1:C  
    Hc=length(indx{c});
    mSigmaHc=zeros(Hc);
    G=NA(indx{c},indx{c})*IHA(indx{c},indx{c})*NA(indx{c},indx{c})';
    qa2c=zeros(Hc,1);
    qa1=pa1+0.5*(T-1);
    av=avHtHt(indx{c},indx{c});
    hatAc=hatA(indx{c},indx{c});
    pa2c=pa2(indx{c});
    for i=1:Hc
        S=sum(alpha(c)*hatAc(i,:).^2);
        qa2c(i)=pa2c(i)+0.5*(av(i,i)-G(i,i)+S);
        mSigmaHc(i,i)=qa2c(i)/qa1;
    end
    mSigmaH=blkdiag(mSigmaH,mSigmaHc);
    qa2=[qa2;qa2c];
end


    