% Demo for the Variational Bayesian Factorial Linear Gaussian State-Space Model (BFLGSSM)

% We generate some data from a Factorial LGSSM with 2 independent hidden dynamical processes.
% We then infer the most parsimonious parameterization consistent with the data 
% using a variational BFLGSSM. 
% The Variation BFLGSSM finds 2 hidden processes (starting from 5).

%--------------------------------------------------------------------------------------------------------

clear all;close all
maxiter=300; % Number of iterations for Variational EM 
T=256; % Time-series length
oC=2; % Number of independent hidden dynamical processes

% Generate some data
% We assume that the observations are generated from 2 independent hidden dynamical processes, both containing 
% 9.5 and 10 Hz frequencies
Sf=256; % Sample frequency 
omegaHz=2*pi*[9.5 10]/Sf;
nomega=length(omegaHz);
Hc=4*ones(oC,1);
H=sum(Hc);
V=2;
A=[];
for c=1:oC
    rot{c}=[];
    for j=1:nomega
        rot{c}=blkdiag(rot{c},0.99999*rotmat(omegaHz(j)));
    end
    A=blkdiag(A,rot{c});
end
SigmaH=[];
randn('state',1)
mu=0.1*randn(H,1);
Sigma=[];
for c=1:oC
    r=randn(Hc(c));
    SigmaH=blkdiag(SigmaH,0.1*r*r');
    Sigma=blkdiag(Sigma,0.01*eye(Hc(c)));
end
SigmaV=0.01*eye(V);
P=[];
for c=1:oC
  P=blkdiag(P,ones(1,Hc(c)));
end
W=randn(V,oC); B=W*P;
h(:,1)=mvnrnd(mu',Sigma,1)';
v(:,1)=B*h(:,1)+mvnrnd(zeros(V,1),SigmaV,1)';
for t=2:T
    h(:,t)=A*h(:,t-1)+mvnrnd(zeros(H,1),SigmaH,1)';
    v(:,t)=B*h(:,t)+mvnrnd(zeros(V,1),SigmaV,1)';
end

BFLGSSM.v=v;

figure(1),subplot(V,1,1);title('Observations') 
for i=1:V
    subplot(V,1,i)
    hold on
    plot(v(i,:))
end
figure(2),subplot(oC,1,1);title('Hidden Processes') 
ip=P*h;
for c=1:oC
    subplot(oC,1,c)
    hold on
    plot(ip(c,:))
end

% Initialization and setting of hatA and hatW
C=5; % Start from higher number of independent dynamical systems than the original one

% Uncomment when we assume that we know the frequency content of the independent dynamical systems
% omegaHz=2*pi*[9.5 10]/Sf;
% nomega=length(omegaHz);
% Hc=4*ones(oC,1);

% H=sum(Hc);
% hatA=[];
% for c=1:C
%     rot{c}=[];
%     for j=1:nomega
%         rot{c}=blkdiag(rot{c},0.99999*rotmat(omegaHz(j)));
%     end
%     hatA=blkdiag(hatA,rot{c});
% end

% Comment when we assume that we know the frequency content of the independent dynamical systems
Hc=4*ones(C,1);
H=sum(Hc);
BFLGSSM.hatA=zeros(H); % Set hatA to zero to eliminate unecessary dynamical processes
BFLGSSM.hatW=zeros(V,C); % Set hatW to zero to eliminate unecessary dynamical processes
BFLGSSM.mA=[];
for c=1:C
  BFLGSSM.mA=blkdiag(BFLGSSM.mA,0.99999*orth(rand(Hc(c))));
end
BFLGSSM.mSigmaH=[];
BFLGSSM.Sigma=[];
for c=1:C
  BFLGSSM.mSigmaH=blkdiag(BFLGSSM.mSigmaH,0.1*eye(Hc(c)));
  BFLGSSM.Sigma=blkdiag(BFLGSSM.Sigma,0.1*eye(Hc(c)));
end
BFLGSSM.mu=zeros(H,1);
BFLGSSM.mSigmaV=0.1*eye(V);
P=[];
indx{1}=1:Hc(1);
P=blkdiag(P,ones(1,Hc(1)));
for c=2:C
  indx{c}=sum(Hc(1:c-1))+1:sum(Hc(1:c));
  P=blkdiag(P,ones(1,Hc(c)));
end
BFLGSSM.mW=randn(V,C);

BFLGSSM.pa1=2;
BFLGSSM.pa2=0.5*ones(H,1);
BFLGSSM.pb1=2;
BFLGSSM.pb2=0.5*ones(V,1);
BFLGSSM.alpha=0.0001*abs(rand(C,1));
BFLGSSM.beta=0.0001*ones(C,1);

BFLGSSM=VBFLGSSM(maxiter,BFLGSSM,P,indx);

figure(3)
mAn=BFLGSSM.mA./max(max(abs(BFLGSSM.mA)));
act=0;
for c=1:C
    if(max(abs(mAn(indx{c},indx{c})))>10e-5)
        act=act+1;
    end
end
subplot(1,3,1);imagesc(BFLGSSM.mA),colormap(gray)
title({'Mean of q(A): number of independent processes', ['reduced from ' num2str(C) ' to '  num2str(act) ' (data generated with C=' num2str(oC) ')']})
set(gca,'XTick',[length(indx{1})-1.5:length(indx{1}):H])
set(get(gca,'XLabel'),'String','C')
set(gca,'XTickLabel',1:C)
set(gca,'YTick',[length(indx{1})-1.5:length(indx{1}):H])
set(gca,'YTickLabel',1:C)
set(get(gca,'YLabel'),'String','C')
colorbar

mWn=BFLGSSM.mW./max(max(abs(BFLGSSM.mW)));
act=0;
for j=1:C
    if(max(abs(mWn(:,j)))>10e-3)
        act=act+1;
        ac(act)=j;
    end
end
subplot(1,3,2);imagesc(BFLGSSM.mW),colormap(gray)
title({'Mean of q(W): number of columns reduced', ['from ' num2str(C) ' to '  num2str(act) ' (data generated with C=' num2str(oC) ')']})
set(gca,'XTick',[1:C])
set(get(gca,'XLabel'),'String','C')
set(gca,'YTick',[1:V])
set(get(gca,'YLabel'),'String','V')
colorbar

subplot(1,3,3);plot(BFLGSSM.F)
title('Log-likelihood Bound');
axis tight

figure(4),subplot(act,1,1);title('Recovered Active Hidden Processes') 
ip=P*BFLGSSM.mean_post;
for c=1:act
    subplot(act,1,c)
    hold on
    plot(ip(ac(c),:))
end

