%-----------------------------------------------------------------------------------------------------------------
% Variational Bayesian Factorial Linear Gaussian State-Space Models (aka Linear Dynamical Systems, Kalman Filters)
%
% h(t) = Ah(t-1) + etah(t), etah(t)~N(0,SigmaH), etah(1)~N(mu,Sigma)
% v(t) = Bh(t) + etav(t), etav(t)~N(0,SigmaV)

% A, SigmaH and Sigma are assumed to be block diagonal
% B=WP where W is a VxC mixing matrix and 
% P is a CxH projection P=diag(1'_1,...,1'_C) (1_c is a unit vector)
     
% Assume a Gaussian prior on each block Ac and on the columns of B 
% p(A|alpha) propto prod exp[-0.5 alpha(c)(Ac-hatAc)'ISigmaHc(Ac-hatAc)]
% p(B|beta) propto prod exp[-0.5 beta(j)(B_j-hatB_j)'ISigmaV(B(:,j)-hatB(:,j))]

% Assume a Gamma prior on the inverse of diagonal covariances SigmaH and SigmaV
%
% No prior on mu and Sigma, wich are considered as hyperparameters

% References:
% Silvia Chiappa & David Barber 
% Bayesian Linear Gaussian State-Space Models for Biosignal Decomposition. 
% Signal Processing Letters, 14(4): pages 267-270, 2007.

% David Barber & Silvia Chiappa
% Unified Inference for Variational Bayesian Linear Gaussian State-Space Models. 
% In Advances in Neural Information Processing Systems 19 (NIPS 20), pages 81-88, 2007. 

%
% Created in January 2007 by Silvia Chiappa, email: silvia.chiappa@tuebingen.mpg.de
% Last Modification: 06/02/2009
%----------------------------------------------------------------------------------------------------------------

function BFLGSSM=VBFLGSSM(maxiter,BFLGSSM,P,indx)

[V,T]=size(BFLGSSM.v);
H=size(BFLGSSM.mA,1);
C=length(indx);

% Run predictor-corrector and Rauch-Tung-Striebel algorithms
[mean_post,cov_post,pair_cov_post]=forward_pc_backward_rts(BFLGSSM.v,BFLGSSM.mA,BFLGSSM.mW*P,BFLGSSM.mW*P,BFLGSSM.mSigmaH,...
    BFLGSSM.mSigmaV,BFLGSSM.mu,BFLGSSM.Sigma);

%----------------------------------------------------------------------------
% COMPUTE sum <h(t)h(t)'>_q(h(t)) sum <h(t-1)h(t)'>_q(h(t-1:t))
%         sum <h(t)>_q(h(t))v(t)' sum v(t)v(t)'
%----------------------------------------------------------------------------

avHtmHtm=zeros(H);avHtHt=zeros(H);avHtmHt=zeros(H);avH1HtH1Ht=zeros(C);avHtVt=zeros(C,V);avVtVt=zeros(V);
avHtmHtm=sum(cov_post(:,:,1:T-1),3)+mean_post(:,1:T-1)*mean_post(:,1:T-1)';
avHtHt=sum(cov_post(:,:,2:T),3)+mean_post(:,2:T)*mean_post(:,2:T)';
avHtmHt=sum(pair_cov_post(:,:,2:T),3)+mean_post(:,1:T-1)*mean_post(:,2:T)';
avH1HtH1Ht=P*(avHtmHtm+cov_post(:,:,T)+mean_post(:,T)*mean_post(:,T)')*P';
avHtVt=P*mean_post(:,1:T)*BFLGSSM.v(:,1:T)';
avVtVt=BFLGSSM.v(:,1:T)*BFLGSSM.v(:,1:T)';

figure(3)

for emloop=1:maxiter 
    
    if (~mod(emloop,10))
        emloop
    end

    %----------------------------------------------------------------------------
    % COMPUTE THE REQUIRED STATISTICS OF THE PARAMETERS Theta={A,W,SigmaH,SigmaV}
    %----------------------------------------------------------------------------

    [BFLGSSM.mA,SA,NA,IHA]=statA(avHtmHtm,avHtmHt,BFLGSSM.alpha,BFLGSSM.hatA,indx);
    [BFLGSSM.mW,SW,NW,IHW]=statB(avHtVt,avH1HtH1Ht,BFLGSSM.beta,BFLGSSM.hatW);
    [BFLGSSM.mSigmaH,BFLGSSM.qa1,BFLGSSM.qa2]=statSigmaH(avHtHt,BFLGSSM.pa1,BFLGSSM.pa2,...
        BFLGSSM.alpha,BFLGSSM.hatA,NA,IHA,T,indx);
    [BFLGSSM.mSigmaV,BFLGSSM.qb1,BFLGSSM.qb2]=statSigmaV(avVtVt,BFLGSSM.pb1,BFLGSSM.pb2,BFLGSSM.beta,...
        BFLGSSM.hatW,NW,IHW,BFLGSSM.v);

    %---------------------------------------------------------------------------------------------------
    % COMPUTE MEAN AND COVARIANCE OF q(h(t)) AND THE ENTROPY -<log q(h(t))>_q(h(t))
    %---------------------------------------------------------------------------------------------------

    % Run predictor-corrector and Rauch-Tung-Striebel algorithms
    vtilde=[BFLGSSM.v;zeros(H,T);zeros(C,T)];
    Btilde=[BFLGSSM.mW*P;chol(SA);chol(SW)*P];
    BtildeT=[BFLGSSM.mW*P;zeros(H);chol(SW)*P];
    SigmaVtilde=blkdiag(BFLGSSM.mSigmaV,eye(H),eye(C));
    
    [mean_post,cov_post,pair_cov_post,q_entropy]=forward_pc_backward_rts(vtilde,BFLGSSM.mA,Btilde,BtildeT,BFLGSSM.mSigmaH,...
        SigmaVtilde,BFLGSSM.mu,BFLGSSM.Sigma);

    %----------------------------------------------------------------------------
    % COMPUTE sum <h(t)h(t)'>_q(h(t)) sum <h(t-1)h(t)'>_q(h(t-1:t))
    %         sum <h(t)>_q(h(t))v(t)'
    %----------------------------------------------------------------------------

    avHtmHtm=sum(cov_post(:,:,1:T-1),3)+mean_post(:,1:T-1)*mean_post(:,1:T-1)';
    avHtHt=sum(cov_post(:,:,2:T),3)+mean_post(:,2:T)*mean_post(:,2:T)';
    avHtmHt=sum(pair_cov_post(:,:,2:T),3)+mean_post(:,1:T-1)*mean_post(:,2:T)';
    avH1HtH1Ht=P*(avHtmHtm+cov_post(:,:,T)+mean_post(:,T)*mean_post(:,T)')*P';
    avHtVt=P*mean_post(:,1:T)*BFLGSSM.v(:,1:T)';

    %----------------------------------------------------------------
    % CALCULATE LOG-LIKELIHOOD LOWER BOUND F
    %----------------------------------------------------------------

    ImSigmaH=inv(BFLGSSM.mSigmaH);
    mAISigmaHA=SA+BFLGSSM.mA'*ImSigmaH*BFLGSSM.mA;
    ImSigmaV=inv(BFLGSSM.mSigmaV);
    mWISigmaVW=SW+BFLGSSM.mW'*ImSigmaV*BFLGSSM.mW;
    BFLGSSM.F(emloop)=loglik_bound(T,BFLGSSM.qa1,BFLGSSM.qa2,BFLGSSM.pa1,BFLGSSM.pa2,BFLGSSM.qb1,BFLGSSM.qb2,BFLGSSM.pb1,BFLGSSM.pb2,BFLGSSM.alpha,...
        BFLGSSM.beta,ImSigmaH,mAISigmaHA,ImSigmaV,mWISigmaVW,avHtmHtm,avHtmHt,avHtHt,avH1HtH1Ht,avHtVt,avVtVt,IHA,IHW,...
        BFLGSSM.mA,BFLGSSM.mW,BFLGSSM.hatA,BFLGSSM.hatW,BFLGSSM.mu,BFLGSSM.Sigma,mean_post,cov_post,q_entropy,indx);

    %----------------------------------------------------------------
    % UPDATE HYPERPARAMETERS HATTHETA={alpha,beta,mu,Sigma}
    %----------------------------------------------------------------

    % Update hyperparameters alpha 
    for c=1:C
        Hc=length(indx{c});
        mAISigmaHA=SA(indx{c},indx{c})+BFLGSSM.mA(indx{c},indx{c})'*ImSigmaH(indx{c},indx{c})*BFLGSSM.mA(indx{c},indx{c});
        mhatAISigmaHhatA=BFLGSSM.hatA(indx{c},indx{c})'*ImSigmaH(indx{c},indx{c})*BFLGSSM.hatA(indx{c},indx{c});
        mAISigmaHhatA=BFLGSSM.mA(indx{c},indx{c})'*ImSigmaH(indx{c},indx{c})*BFLGSSM.hatA(indx{c},indx{c});
        BFLGSSM.alpha(c)=Hc^2/trace(mAISigmaHA-2*mAISigmaHhatA+mhatAISigmaHhatA);
    end

    % Update hyperparameters beta
    mhatWISigmaVhatW=BFLGSSM.hatW'*ImSigmaV*BFLGSSM.hatW;
    mWISigmaVhatW=BFLGSSM.mW'*ImSigmaV*BFLGSSM.hatW;
    for j=1:C
        BFLGSSM.beta(j)=V/(mWISigmaVW(j,j)-2*mWISigmaVhatW(j,j)+mhatWISigmaVhatW(j,j));
    end

    % Update mean and covariance of h(1)
    % mu=mean_post(:,1);
    % for c=1:C
    %     Sigma(indx{c},indx{c})=cov_post(indx{c},indx{c},1);
    % end
    for c=1:C
        CT=-mean_post(indx{c},1)*BFLGSSM.mu(indx{c})';
        BFLGSSM.Sigma(indx{c},indx{c})=cov_post(indx{c},indx{c},1)+mean_post(indx{c},1)*mean_post(indx{c},1)'+CT+CT'+BFLGSSM.mu(indx{c})*BFLGSSM.mu(indx{c})';
    end
    BFLGSSM.mu=mean_post(:,1);


    if (~mod(emloop,10))
        mAn=BFLGSSM.mA./max(max(abs(BFLGSSM.mA)));
        act=0;
        for c=1:C
            if(max(abs(mAn(indx{c},indx{c})))>10e-5)
                act=act+1;
            end
        end
        subplot(1,3,1);imagesc(BFLGSSM.mA),colormap(gray)
        title('Mean of q(A)')
        set(gca,'XTick',[length(indx{1})-1.5:length(indx{1}):H])
        set(get(gca,'XLabel'),'String','C')
        set(gca,'XTickLabel',1:C)
        set(gca,'YTick',[length(indx{1})-1.5:length(indx{1}):H])
        set(gca,'YTickLabel',1:C)
        set(get(gca,'YLabel'),'String','C')
        colorbar

        mWn=BFLGSSM.mW./max(max(abs(BFLGSSM.mW)));
        act=0;
        for j=1:C
            if(max(abs(mWn(:,j)))>10e-5)
                act=act+1;
            end
        end
        subplot(1,3,2);imagesc(BFLGSSM.mW),colormap(gray)
        title('Mean of q(W)')
        set(gca,'XTick',[1:C])
        set(get(gca,'XLabel'),'String','C')
        set(gca,'YTick',[1:V])
        set(get(gca,'YLabel'),'String','V')
        colorbar

        subplot(1,3,3);plot(BFLGSSM.F)
        title('Log-likelihood Bound');
        axis tight
        drawnow
    end

end

BFLGSSM.mean_post=mean_post;








  
  






