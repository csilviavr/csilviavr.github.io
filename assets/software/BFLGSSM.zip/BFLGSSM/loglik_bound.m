function bound=loglik_bound(T,qa1,qa2,pa1,pa2,qb1,qb2,pb1,pb2,alpha,beta,ImSigmaH,mAISigmaHA,ImSigmaV,mBISigmaVB,avHtmHtm,avHtmHt,avHtHt,avH1HtH1Ht,avHtVt,avVtVt,IHA,IHB,mA,mB,hatA,hatB,mu,Sigma,mean_post,cov_post,q_entropy,indx)

% Calculate the log-likelihood lower bound 

C=size(avHtVt,1);
H=size(ImSigmaH,1);
V=size(ImSigmaV,1);

P=[];
for c=1:C
  Hc=length(indx{c});
  P=blkdiag(P,ones(1,Hc));
end

tmp1=ImSigmaH*avHtHt;  
tmp3=ImSigmaH*mA*avHtmHt; 
tmp4=mAISigmaHA*avHtmHtm; 

tmp5=ImSigmaV*avVtVt;  
tmp7=ImSigmaV*mB*avHtVt; 
tmp8=mBISigmaVB*avH1HtH1Ht; 

digammah=psi(qa1); 
%digammah=mfun('Psi',qa1);
digammav=psi(qb1); 
%digammav=mfun('Psi',qb1);

bound=-0.5*(trace(tmp1)-2*trace(tmp3)+trace(tmp4)...
    -(T-1)*(sum(digammah-log(qa2))-H*log(2*pi))); % <log p(h(2:T)|h(1)))>_q(h(1:T))q(A,SigmaH)

CT=-mean_post(:,1)*mu';
bound=bound-0.5*trace(inv(Sigma)*(cov_post(:,:,1)+mean_post(:,1)*mean_post(:,1)'...
    +CT+CT'+mu*mu'))-0.5*lndet(Sigma)-0.5*H*log(2*pi); % <log p(h(1)|v(1:T))>_q(h(1))

bound=bound-0.5*((trace(tmp5)-2*trace(tmp7)+trace(tmp8))...
    -T*(sum(digammav-log(qb2))-V*log(2*pi))); % <log p(v(1:T)|h(1:T))>_q(h(1:T))q(B,SigmaV)

bound=bound-KL_gamma(qa1,qa2,pa1,pa2); % <log q(ISigmaH)/p(ISigmaH)>_q(ISigmaH)
bound=bound-KL_gamma(qb1,qb2,pb1,pb2); % <log q(ISigmaV)/p(ISigmaV)>_q(ISigmaV)

bound=bound+q_entropy;

% <log q(A|ISigmaH)/p(A|ISigmaH)>_q(A,ISigmaH)
for c=1:C
    Hc=length(indx{c});
    bound=bound-(-Hc/2*(Hc*log(alpha(c))+lndet(IHA(indx{c},indx{c})))...
        +Hc/2*trace(alpha(c)*(IHA(indx{c},indx{c}))-eye(Hc))...
        +1/2*trace(alpha(c)*(mA(indx{c},indx{c})-hatA(indx{c},indx{c}))'...
        *ImSigmaH(indx{c},indx{c})*(mA(indx{c},indx{c})-hatA(indx{c},indx{c})))...
        );
end

% <log q(B|ISigmaV)/p(B|ISigmaV)>_q(B,ISigmaV)
bound=bound-(-V/2*(log(prod(beta))+lndet(IHB))...
    +V/2*trace(diag(beta)*IHB-eye(C))...
    +1/2*trace(diag(beta)*(mB-hatB)'*ImSigmaV*(mB-hatB))...
    );
