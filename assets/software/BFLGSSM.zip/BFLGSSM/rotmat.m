function A=rotmat(theta)
  
  A=0.999*[cos(theta) -sin(theta); sin(theta) cos(theta)];