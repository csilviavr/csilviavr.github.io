function [mA,SA,NA,IHA]=statA(avHtmHtm,avHtmHt,alpha,hatA,indx)

% Compute the mean of q(A|SigmaH) and SA=<A'SigmaH^{-1}A>-<A'><SigmaH^{-1}><A>

C=length(indx);
mA=[];
SA=[];
NA=[];
IHA=[];

for c=1:C  
    Hc=length(indx{c});
    av=avHtmHtm(indx{c},indx{c});
    HA=zeros(Hc);
    for j=1:Hc
        HA(j,:)=av(j,:);
    end
    HA=HA+alpha(c)*eye(Hc);
    IHAc=inv(HA);
    IHA=blkdiag(IHA,IHAc);
    av=avHtmHt(indx{c},indx{c});
    hatAc=hatA(indx{c},indx{c});
    NAc=zeros(Hc);
    for i=1:Hc
        NAc(i,:)=av(:,i)'+alpha(c)*hatAc(i,:); 
    end
    NA=blkdiag(NA,NAc);
    mA=blkdiag(mA,NAc*IHAc);
    SA=blkdiag(SA,Hc*IHAc);
end
SA=0.5*(SA+SA');


    


  
    
    
    
    
	   
    
    