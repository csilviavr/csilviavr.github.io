function [mW,SW,NW,IHW]=statB(avHtVt,avHtHt,beta,hatW)

% Compute the mean of q(B|SigmaV) and SB=<B'SigmaV^{-1}B>-<B'><SigmaV^{-1}><B>

[C,V]=size(avHtVt);
HW=zeros(C);
NW=zeros(V,C);

for i=1:C
    HW(i,:)=avHtHt(:,i)';
end
HW=HW+diag(beta);
IHW=inv(HW);
for i=1:V
    NW(i,:)=avHtVt(:,i)'+beta'.*hatW(i,:); 
end
mW=NW*IHW;
SW=V*IHW;
SW=0.5*(SW+SW');

    
    
    
	   
    
    